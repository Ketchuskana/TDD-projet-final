import json
import boto3
from botocore.exceptions import ClientError

dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('userTable')  # Nom de ta table DynamoDB

def lambda_handler(event, context):
    try:
        data = json.loads(event['body'])
        user_id = data['userID']
        name = data['name']
        email = data['email']

        # Ajout dans DynamoDB
        table.put_item(
            Item={
                'userID': user_id,
                'name': name,
                'email': email
            }
        )
        return {
            'statusCode': 200,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*',  
            },
            'body': json.dumps({'message': 'User saved successfully!'})
        }
    except KeyError as e:
        return {
            'statusCode': 400,
            'body': json.dumps({'error': f'Missing field {str(e)}'})
        }
    except ClientError as e:
        return {
            'statusCode': 500,
            'body': json.dumps({'error': 'Could not save user'})
        }
